# 	    Operating System Lab 03

### Instructor : Sir Nouman Shafi
### Reg No: 2022-CS-51
### Name : Zohaib Arshad

# Linux Commands:

## Linux Basics
### 1:   Echo
The echo command is varsatile and is often used for printing messages.
<img src="/home/vboxuser/Desktop/Lab3/Screenshot from 2024-02-04 12-01-22.png" alt="Screenshot from 2024-02-04 12-01-22" style="zoom: 50%;" />

### 2:  Uptime
This command prints the time on screen
<img src="/home/vboxuser/Desktop/Lab3/Screenshot from 2024-02-04 12-02-14.png" alt="Screenshot from 2024-02-04 12-02-14" style="zoom:50%;" />

### 3:  Pwd
Pwd present Working Directory
<img src="/home/vboxuser/Desktop/Lab3/Screenshot from 2024-02-04 12-03-05.png" alt="Screenshot from 2024-02-04 12-03-05" style="zoom:50%;" />
### 4:  ls
Provides List Contents of the current directory
<img src="/home/vboxuser/Desktop/Lab3/Screenshot from 2024-02-04 12-03-21.png" alt="Screenshot from 2024-02-04 12-03-21" style="zoom:50%;" />
### 5:  mkdir and cd commands
a: mkdir command is used to create Directory at your desired location.
b: cd or Change directory is used to locate at your desired destination.

<img src="/home/vboxuser/Desktop/Lab3/Screenshot from 2024-02-04 12-04-29.png" alt="Screenshot from 2024-02-04 12-04-29" style="zoom:50%;" />
## Basic Commands: Reading Files
### 6:  touch , cat
a: touch command is used to create Text File 
b: cat command is used to read Text File that created.
<img src="/home/vboxuser/Desktop/Lab3/Screenshot from 2024-02-04 12-11-30.png" alt="Screenshot from 2024-02-04 12-11-30" style="zoom:50%;" />

### 7:  Head or Tail
head : Output the file from beginning for a specific number of lines
Tail:  from end for a specific number of lines
<img src="/home/vboxuser/Desktop/Lab3/Screenshot from 2024-02-04 12-12-24.png" alt="Screenshot from 2024-02-04 12-12-24" style="zoom:50%;" />
## Basic Linux Commands:Pager
### 8: more command
Scrolls the display ,one screenful of a data at a time

<img src="/home/vboxuser/Desktop/Lab3/Screenshot from 2024-02-04 12-13-31.png" alt="Screenshot from 2024-02-04 12-13-31" style="zoom:50%;" />

### 9: less command
Scrolls down the display ,one time
<img src="/home/vboxuser/Desktop/Lab3/Screenshot from 2024-02-04 12-13-50.png" alt="Screenshot from 2024-02-04 12-13-50" style="zoom:50%;" />
## Basic Commands ls
### 10: ls -l
Long list
<img src="/home/vboxuser/Desktop/Lab3/Screenshot from 2024-02-04 12-14-28.png" alt="Screenshot from 2024-02-04 12-14-28" style="zoom:50%;" />

### 11: ls -a
Details about, what folders are in the current Directory

<img src="/home/vboxuser/Desktop/Lab3/Screenshot from 2024-02-04 12-15-30.png" alt="Screenshot from 2024-02-04 12-15-30" style="zoom:50%;" />
## Command Line Help
### 12:  Whatis
Used to display a brief explanation of command
<img src="/home/vboxuser/Desktop/Lab3/Screenshot from 2024-02-04 12-17-20.png" alt="Screenshot from 2024-02-04 12-17-20" style="zoom:50%;" />

<img src="/home/vboxuser/Desktop/Lab3/Screenshot from 2024-02-04 12-18-51.png" alt="Screenshot from 2024-02-04 12-18-51" style="zoom:50%;" />
# Most Used Commands:
### 13:  gedit
It is used to open a text file
<img src="/home/vboxuser/Desktop/Lab3/Screenshot from 2024-02-04 12-25-01.png" alt="Screenshot from 2024-02-04 12-25-01" style="zoom:50%;" />

### 14: nano
It is used for editing text on run time through terminal having different features.It opens the save text file first then you can make changes easily. 

![Screenshot from 2024-02-04 12-28-20](/home/vboxuser/Desktop/Lab3/Screenshot from 2024-02-04 12-28-20.png)

### 15:  cp
cp command is basically used for copying files, folders by source to destination.

<img src="/home/vboxuser/Desktop/Lab3/Screenshot from 2024-02-04 12-39-26.png" alt="Screenshot from 2024-02-04 12-39-26" style="zoom:50%;" />

### 16: rm command
rm command is used to remove files.

<img src="/home/vboxuser/Desktop/Lab3/Screenshot from 2024-02-04 12-40-28.png" alt="Screenshot from 2024-02-04 12-40-28" style="zoom:50%;" />

### 17: mv 
mv command is used to move files data from current file to another file.

<img src="/home/vboxuser/Desktop/Lab3/Screenshot from 2024-02-04 12-46-16.png" alt="Screenshot from 2024-02-04 12-46-16" style="zoom:50%;" />

### 18: find
find command is used to find the specified folder and it also give complete path where it locate.

<img src="/home/vboxuser/Desktop/Lab3/Screenshot from 2024-02-04 12-47-26.png" alt="Screenshot from 2024-02-04 12-47-26" style="zoom:50%;" />

### 19: history
It provides the complete details of all data ,files or directories that are created ,exists or delete.

<img src="/home/vboxuser/Desktop/Lab3/Screenshot from 2024-02-04 12-48-12.png" alt="Screenshot from 2024-02-04 12-48-12" style="zoom:50%;" />

### 20: wc
wc gives the count of text file by providing the total number of lines,characters or words.

<img src="/home/vboxuser/Pictures/Screenshots/Screenshot from 2024-02-04 12-49-39.png" alt="Screenshot from 2024-02-04 12-49-39" style="zoom:50%;" />
# User and Groups in linux
### 21: cat /etc/passwd
<img src="/home/vboxuser/Pictures/Screenshots/Screenshot from 2024-02-04 17-37-03.png" alt="Screenshot from 2024-02-04 17-37-03" style="zoom:50%;" />

### 22: id,who and last
are used to retrieve information about users and their activities..

<img src="/home/vboxuser/Pictures/Screenshots/Screenshot from 2024-02-04 17-39-58.png" alt="Screenshot from 2024-02-04 17-39-58" style="zoom:50%;" />
### Github Link:

**GitHub** Repository : [Link](https://github.com/zuhaibarshad-786/OS-Lab.git/).













